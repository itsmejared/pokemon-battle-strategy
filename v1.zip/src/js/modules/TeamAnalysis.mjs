export default class TeamAnalysis {}
