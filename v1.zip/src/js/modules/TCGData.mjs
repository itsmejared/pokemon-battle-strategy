export default class TCGData {}
