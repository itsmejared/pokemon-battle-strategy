export default class TypeCoverage {}
