export default class TeamStorage {}
